<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['submit'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass']);
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
   $select_user->execute([$email,]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);

   if($select_user->rowCount() > 0){
      $message[] = 'email already exists!';
   }else{
      if($pass != $cpass){
         $message[] = 'confirm password not matched!';
      }else{
         $insert_user = $conn->prepare("INSERT INTO `users`(name, email, password) VALUES(?,?,?)");
         $insert_user->execute([$name, $email, $cpass]);
         $message[] = 'registered successfully, login now please!';
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>AstroShop | Register</title>
  <link rel="icon" type="image/x-icon" href="favicon.png">
   
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
   
<?php include 'components/header.php'; ?>

<section class="form-container d-flex justify-content-center align-items-center vh-100 bg-gradient">
   <div class="bg-white p-4 rounded-3 shadow" style="max-width: 400px; width: 100%;">
      <h3 class="text-primary text-center mb-4" style="letter-spacing: 1.5px; font-weight: 700;">Register Now</h3>

      <form action="" method="post">
         <div class="mb-3">
            <label for="name" class="form-label text-dark fw-bold">Username</label>
            <div class="input-group">
               <span class="input-group-text"><i class="fas fa-user"></i></span>
               <input type="text" name="name" id="name" required placeholder="Enter your username" maxlength="20" 
                      class="form-control rounded-3">
            </div>
         </div>

         <div class="mb-3">
            <label for="email" class="form-label text-dark fw-bold">Email Address</label>
            <div class="input-group">
               <span class="input-group-text"><i class="fas fa-envelope"></i></span>
               <input type="email" name="email" id="email" required placeholder="Enter your email" maxlength="50" 
                      class="form-control rounded-3" oninput="this.value = this.value.replace(/\s/g, '')">
            </div>
         </div>

         <div class="mb-3">
            <label for="pass" class="form-label text-dark fw-bold">Password</label>
            <div class="input-group">
               <span class="input-group-text"><i class="fas fa-lock"></i></span>
               <input type="password" name="pass" id="pass" required placeholder="Enter your password" maxlength="20" 
                      class="form-control rounded-3" oninput="this.value = this.value.replace(/\s/g, '')">
            </div>
         </div>

         <div class="mb-3">
            <label for="cpass" class="form-label text-dark fw-bold">Confirm Password</label>
            <div class="input-group">
               <span class="input-group-text"><i class="fas fa-lock"></i></span>
               <input type="password" name="cpass" id="cpass" required placeholder="Confirm your password" maxlength="20" 
                      class="form-control rounded-3" oninput="this.value = this.value.replace(/\s/g, '')">
            </div>
         </div>

         <div class="text-center mt-4">
            <input type="submit" value="Register Now" name="submit" class="btn btn-primary w-100 py-2 rounded-3">
         </div>
      </form>

      <div class="text-center mt-3">
         <p class="m-0">Already have an account?</p>
         <a href="login.php" class="btn btn-link text-primary p-0" style="font-size: 1rem; text-decoration: none;">Login Now</a>
      </div>
   </div>
</section>






<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>